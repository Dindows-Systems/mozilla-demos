#include <system.h>

char *getcmdline(int *bootinfo)
{
	if (bootinfo[0] >> 2 % 2) {
		return (char *) bootinfo[4];
	} else {
		return 0x0;
	}
	return 0x0;
}

char *getbootloader(int *bootinfo)
{
	if (bootinfo[0] >> 9 % 2) {
		return (char *) bootinfo[16];
	} else {
		return 0x0;
	}
	return 0x0;
}

// Main function
void kmain(int *bootinfo)
{
	char *cmdline = getcmdline(bootinfo);
	char *bootloader = getbootloader(bootinfo);

	screen_init();
	color_table("DUX");
	puts(bootloader);
	puts(cmdline);
	for(;;) asm("hlt");
}
