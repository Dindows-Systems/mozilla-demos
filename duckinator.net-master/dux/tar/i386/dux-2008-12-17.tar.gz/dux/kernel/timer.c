#include <system.h>
#include <stdint.h>
#include <dux/idt.h>

/* This will keep track of how many ticks that the system
*  has been running for */
int timer_ticks = 0;

/* Handles the timer. In this case, it's very simple: We
*  increment the 'timer_ticks' variable every time the
*  timer fires. By default, the timer fires 18.222 times
*  per second. Why 18.222Hz? Some engineer at IBM must've
*  been smoking something funky */
void timer_handler(struct pic_data *r)
{
	r=r; // Stop the warning about int_no being unused

	/* Increment our 'tick count' */
	timer_ticks++;

	puts("TICK\n");

	/* Every 18 clocks (approximately 1 second), we will
	*  display a message on the screen */
	/*if (timer_ticks % 18 == 0)
	{
		puts("One second has passed\n");
	}*/
}

/* This will continuously loop until the given time has
*  been reached */
void timer_sleep(int ticks)
{
	long eticks;

	eticks = timer_ticks + ticks;
	while(timer_ticks < eticks);
}
