#include <system.h>

// WARNING. This function works best with a text 3 chars long
void color_table(char *text)
{
	puts("   "); 
	screen_set_color(15, 1);
	puts(" 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 \n"); 
	int i, j;
	for (i = 0; i < 16; i++)
	{
		// Is this worthy of the "hack" name?
		if (i < 10)
		{
			putch(' ');
			putch('0'+i);
		} else {
			putch('1');
			putch('0'+i-10);
		}
		putch(' ');
		for (j = 0; j < 16; j++)
		{
			screen_set_color(j, i);
			puts(text);
		}
		screen_set_color(15, 1);
		putch('\n');
	}
	screen_set_color(15, 0);
}
