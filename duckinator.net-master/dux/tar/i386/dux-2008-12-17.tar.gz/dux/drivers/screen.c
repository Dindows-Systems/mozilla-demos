// Screen.c - Screen driver. Mostly taken from bran's kernel development tutorial

#include <dux/ports.h>
#include <system.h>

// Defs for bg and fg colours, and x and y cursor coords
unsigned short *screen_memory;
int screen_attrib = 0x0F;
int screen_cursor_x = 0;
int screen_cursor_y = 0;

// Screen dimensions
int screen_width = 80;
int screen_height = 25;

// Tab size
unsigned char screen_tab_width = 4;

/*
 * ANSI escape seqence parser variables. ansi_flags is a bitfield used
 * to incremently parse sequences and args are used to store the values
 * contained by n = ansi_args_count ANSI sequences.
 * The first n = ansi_args_count nulls in ansi_args seperate arguments.
 */
unsigned char ansi_flags = 0;
char ansi_args[256];
unsigned char ansi_args_count;

void screen_scroll()
{
	char blank, temp;

	// Blank is defined as space, so it needs backcolor
	blank = 0x20 | (screen_attrib << 8);

	// If we're at row 25, we needz to scroll up
	if (screen_cursor_y >= screen_height)
	{
		// Move current chunk of text up a line
		temp = screen_cursor_y - screen_height + 1;
		memcpy((unsigned char*) screen_memory, (unsigned char*) screen_memory + temp * screen_width, (screen_height - temp) * screen_width * 2);

		memsetw(screen_memory + (screen_height - temp) * screen_width, blank, screen_width);
		screen_cursor_y = screen_height - 1;
	}
}

void screen_update_cursor()
{
	char temp;

	// Get the linear address of the cursor;
	temp = screen_cursor_y * screen_width + screen_cursor_x;

	// Send the high byte.
	outb(0x3D4, 14);
	outb(0x3D5, temp >> 8);

	// Send the low byte.
	outb(0x3D4, 15);
	outb(0x3D5, temp);
}

/* Clears the screen */
void screen_clear()
{
	char blank;
	int i;

	// Again, we need the 'short' that will be used to
	// represent a space with color
	blank = 0x20 | (screen_attrib << 8);

	// Sets the entire screen to spaces in our current color
	for(i = 0; i < screen_height; i++)
		memsetw(screen_memory + i * screen_width, blank, screen_width);

	// Update our virtual cursor, and then move the hardware cursor
	screen_cursor_x = 0;
	screen_cursor_y = 0;
	screen_update_cursor();
}

// Puts a single character on the screen
void putch(char c)
{
    unsigned short *where;
    unsigned att = screen_attrib << 8;

    // Handle a backspace, by moving the cursor back one space
    if(c == 0x08) {
        if(screen_cursor_x != 0) screen_cursor_x--;
    }
    // Handles a tab by incrementing the cursor's x, but only
    // to a point that will make it divisible by n = screen_tab_width
    else if(c == 0x09) {
        screen_cursor_x = (screen_cursor_x + screen_tab_width) & ~(screen_tab_width - 1);
    }
    // Handles a 'Carriage Return', which simply brings the
    // cursor back to the margin
    else if(c == '\r') {
        screen_cursor_x = 0;
    }
    // We handle our newlines the way DOS and the BIOS do: we treat it
    // as if a 'CR' was also there, so we bring the cursor to the
    // margin and we increment the 'y' value
    else if(c == '\n') {
        screen_cursor_x = 0;
        screen_cursor_y++;
    }
    /*
     * Any character greater than and including a space, is a printable
     * character. The equation for finding the index in a linear chunk
     * of memory can be represented by:
     * Index = [(y * width) + x]
     */
    else if(c >= ' ') {
        where = screen_memory + (screen_cursor_y * screen_width + screen_cursor_x);
        *where = c | att;	// Character AND attributes: color
        screen_cursor_x++;
    }

    // If the cursor has reached the edge of the screen's width, we
    // insert a new line in there
    if(screen_cursor_x >= screen_width) {
        screen_cursor_x = 0;
        screen_cursor_y++;
    }

    // Scroll the screen if needed, and finally move the cursor
    screen_scroll();
    screen_update_cursor();
}

// Uses the above routine to output a string...
void puts(char *text)
{
    int i;
    for (i = 0; i < strlen(text); i++)
    {
        putch(text[i]);
    }
}

// Sets the forecolor and backcolor that we will use
void screen_set_color(unsigned char forecolor, unsigned char backcolor)
{
    // Top    4 bytes are the background color
    // Bottom 4 bytes are the foreground color
    screen_attrib = (backcolor << 4) | (forecolor & 0x0F);
}

// Sets our text-mode VGA pointer, then clears the screen for us
void screen_init(void)
{
    screen_memory = (unsigned short *)0xB8000;
    screen_clear();
}
