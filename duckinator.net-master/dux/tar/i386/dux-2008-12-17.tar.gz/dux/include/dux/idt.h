#ifndef _DUX_IDT_H
#define _DUX_IDT_H

void idt_set_entry(uint8_t no, uint32_t offset, uint16_t selector, uint8_t type);

struct pic_data {
	uint32_t no;
	uint32_t gs, fs, es, ds;
	uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
	uint32_t eip, cs, eflags, useresp, ss;
} __attribute__((packed));

#endif
