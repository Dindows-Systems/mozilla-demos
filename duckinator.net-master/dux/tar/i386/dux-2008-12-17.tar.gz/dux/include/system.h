// Basic functions
extern unsigned char *memcpy(unsigned char *dest, const unsigned char *src, int count);
extern unsigned char *memset(unsigned char *dest, unsigned char val, int count);
extern unsigned short *memsetw(unsigned short *dest, unsigned short val, int count);
extern int strlen(const char *str);

// Screen functions
void screen_scroll(void);
void screen_update_cursor(void);
void screen_clear();
void putch(char c);
void puts(char *text);
void screen_init(void);
void screen_set_color(unsigned char forecolor, unsigned char backcolor);
void color_table(char *text);

// System clock functions
extern void timer_sleep(int ticks);
extern void timer_install();
