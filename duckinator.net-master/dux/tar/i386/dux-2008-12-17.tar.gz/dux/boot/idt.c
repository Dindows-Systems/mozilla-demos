/*
 * [boot/idt.c]
 * IDT management helpers.
 *
 * 2008 Copyright © Martin Brandenburg
 */

#include <stdint.h>

#include <dux/idt.h>

extern void load_idt();

struct idt_entry {
	uint16_t offset_1;
	uint16_t selector;
	uint8_t zero;
	uint8_t type;
	uint16_t offset_2;
} __attribute__((packed));

struct idt_desc {
	uint16_t length;
	uint32_t offset;
} __attribute__((packed));

struct idt_entry idt[256];
struct idt_desc idtp;

void idt_init()
{
	// Set the descriptor to point to the IDT.
	idtp.length = sizeof(idt) - 1;
	idtp.offset = (uint32_t) &idt;

	// Create a blank entry;
	struct idt_entry blank;
	blank.offset_1 = 0x0;
	blank.selector = 0x0;
	blank.zero = 0x0;
	blank.type = 0x0;
	blank.offset_2 = 0x0;

	// Clear the descriptor.
	uint16_t i;
	for (i = 0; i < sizeof(idt); i++) {
		idt[i] = blank;
	}

	load_idt();
}

void idt_set_entry(uint8_t no, uint32_t offset, uint16_t selector, uint8_t type)
{
	idt[no].offset_1 = offset & 0xFFFF;
	idt[no].selector = selector;
	idt[no].zero = 0x0;
	idt[no].type = type;
	idt[no].offset_2 = offset >> 16 & 0xFFFF;
}

