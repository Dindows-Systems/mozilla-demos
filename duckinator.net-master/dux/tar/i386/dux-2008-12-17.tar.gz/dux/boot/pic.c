#include <system.h>
#include <stdint.h>

#include <dux/ports.h>
#include <dux/idt.h>
extern void timer_handler(struct pic_data *r);

void *pic_handlers[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

extern void isr32();
extern void isr33();
extern void isr34();
extern void isr35();
extern void isr36();
extern void isr37();
extern void isr38();
extern void isr39();
extern void isr40();
extern void isr41();
extern void isr42();
extern void isr43();
extern void isr44();
extern void isr45();
extern void isr46();
extern void isr47();

void pic_init()
{
	uint8_t mask1, mask2;
	
	// Get the current masks.
	mask1 = inb(0x21);
	mask2 = inb(0xa1);

	// Start the initialization process.
	outb(0x20, 0x11);
	outb(0xa0, 0x11);

	// Define the PIC interrupt vector offsets.
	// Master: 32 - 39
	// Slave: 40 - 47
	outb(0x21, 32);
	outb(0xa1, 40);

	// This does... something?
	// Can someone figure out what this does?
	outb(0x21, 4);
	outb(0xa1, 2);

	// Set the mode.
	// 8086: 0x01
	// AUTO: 0x02
	// Buffered slave: 0x08
	// Buffered master: 0x0c
	// Special fully nested (not): 0x10
	outb(0x21, 0x01);
	outb(0xa1, 0x01);

	// Restore masks.
	outb(0x21, mask1);
	outb(0x21, mask2);
}
void pic_handler_init()
{
	pic_handlers[0] = (*timer_handler);//(struct pic_data *r);
	idt_set_entry(32, (unsigned) isr32, 0x08, 0x8e);
	idt_set_entry(33, (unsigned) isr33, 0x08, 0x8e);
	idt_set_entry(34, (unsigned) isr34, 0x08, 0x8e);
	idt_set_entry(35, (unsigned) isr35, 0x08, 0x8e);
	idt_set_entry(36, (unsigned) isr36, 0x08, 0x8e);
	idt_set_entry(37, (unsigned) isr37, 0x08, 0x8e);
	idt_set_entry(38, (unsigned) isr38, 0x08, 0x8e);
	idt_set_entry(39, (unsigned) isr39, 0x08, 0x8e);
	idt_set_entry(40, (unsigned) isr40, 0x08, 0x8e);
	idt_set_entry(41, (unsigned) isr41, 0x08, 0x8e);
	idt_set_entry(42, (unsigned) isr42, 0x08, 0x8e);
	idt_set_entry(43, (unsigned) isr43, 0x08, 0x8e);
	idt_set_entry(44, (unsigned) isr44, 0x08, 0x8e);
	idt_set_entry(45, (unsigned) isr45, 0x08, 0x8e);
	idt_set_entry(46, (unsigned) isr46, 0x08, 0x8e);
	idt_set_entry(47, (unsigned) isr47, 0x08, 0x8e);
}

static void eoi(uint32_t no)
{
	// Send to the slave if needed.
	if (no > 39)
		outb(0xa0, 0x20);

	// Always send to the master PIC.
	outb(0x20, 20);
}

void pic_handle(struct pic_data *r)
{
	/*  I can’t use this yet!
	void (*handler)(struct pic_data *r);

	handler = pic_handlers[r->no - 32];
	if (handler)
		handler(r);*/

	// Send the EOI message.
	eoi(r->no);
}

